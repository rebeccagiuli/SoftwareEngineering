package edu.fsu.cs.cen4020.showMe;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import edu.fsu.cs.cen4020.showMe.R;

public class Activity_Login extends AppCompatActivity {

    RelativeLayout relLay1, relLay2;
    TextView titleView;
    Button loginBtn, signUpBtn;
    EditText email, password;
    SQLiteOpenHelper openHelper;
    SQLiteDatabase db;
    Cursor cursor;

    Handler handler = new Handler();
    Runnable runnable = new Runnable() {
        @Override
        public void run() {
            relLay1.setVisibility(View.VISIBLE);
            relLay2.setVisibility(View.VISIBLE);
            titleView.setVisibility(View.VISIBLE);

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity__login);

        openHelper = new DatabaseHelper(this);
        db = openHelper.getReadableDatabase();

        relLay1 = findViewById(R.id.rel_layout1);
        relLay2 = findViewById(R.id.rel_layout2);
        titleView = findViewById(R.id.textView_title);
        loginBtn = findViewById(R.id.button_login);
        signUpBtn = findViewById(R.id.button_signUp);
        email = findViewById(R.id.editText_email);
        password = findViewById(R.id.editText_password);

        loginBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if (isEmpty(email)) {

                    email.setError("Enter your email");
                }
                if (isEmpty(password)) {

                    password.setError("Enter your password");
                }
                else {
                    String emailStr = email.getText().toString();
                    String passwordStr = password.getText().toString();
                    cursor = db.rawQuery("SELECT * FROM " + DatabaseHelper.DatabaseEntry.TABLE_NAME + " WHERE "
                            + DatabaseHelper.DatabaseEntry.EMAIL
                            + "=? AND "
                            + DatabaseHelper.DatabaseEntry.CONFIRMED_PASSWORD
                            + "=?", new String[]{emailStr, passwordStr});

                    if (cursor != null) {
                        if (cursor.getCount() > 0) {
                            cursor.moveToNext();
                            Toast.makeText(getApplicationContext(), "Login Successful!", Toast.LENGTH_LONG).show();
                            Intent myIntent = new Intent(Activity_Login.this, UserProfileActivity.class);
                            startActivityForResult(myIntent, 0);
                        } else {
                            Toast.makeText(getApplicationContext(), "Username or Password incorrect. Try again!", Toast.LENGTH_LONG).show();
                        }
                    }
                }
            }
        });

        signUpBtn.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                Intent myIntent = new Intent(Activity_Login.this, SignUpActivity.class);
                startActivityForResult(myIntent, 0);
            }
        });

        handler.postDelayed(runnable, 2000);

    }

    boolean isEmpty(EditText text) {
        CharSequence str = text.getText().toString();
        return TextUtils.isEmpty(str);
    }


}
