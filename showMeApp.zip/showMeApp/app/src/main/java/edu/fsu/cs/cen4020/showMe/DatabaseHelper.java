package edu.fsu.cs.cen4020.showMe;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;
import android.util.Log;
import java.util.Locale;

import static android.content.ContentValues.TAG;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "showMe.db";
    public static final int DATABASE_VERSION = 3;
    private SQLiteDatabase db;
    private Cursor cursor;

    public class DatabaseEntry implements BaseColumns {
        public static final String TABLE_NAME = "userProfiles";
        public static final String _ID = "_id";
        public static final String EMAIL = "email";
        public static final String NAME = "name";
        public static final String CONFIRMED_PASSWORD = "password";
    }

    public static final String SQL_CREATE_DATABASE_TABLE =
            String.format(Locale.US, "CREATE TABLE %s (" // TABLENAME
                            + " %s INTEGER PRIMARY KEY AUTOINCREMENT, " // COLUMN_ID
                            + " %s TEXT NOT NULL," // COLUMN_EMAIL
                            + " %s TEXT NOT NULL," // COLUMN_NAME
                            + " %s TEXT NOT NULL);", //COLUMN_PASSWORD
                    DatabaseEntry.TABLE_NAME, DatabaseEntry._ID, DatabaseEntry.NAME,
                    DatabaseEntry.EMAIL, DatabaseEntry.CONFIRMED_PASSWORD);

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.i(TAG, "Creating: " + SQL_CREATE_DATABASE_TABLE);
        db.execSQL(SQL_CREATE_DATABASE_TABLE);
    }

    public boolean insert(String name, String email, String password) {
        db = this.getWritableDatabase();
        cursor = db.rawQuery("SELECT * FROM " + DatabaseEntry.TABLE_NAME
                + " WHERE " + DatabaseEntry.EMAIL + "=? ", new String[]{email});

        if (cursor.getCount() == 0) {
            ContentValues contentValues = new ContentValues();
            contentValues.put(DatabaseEntry.NAME, name);
            contentValues.put(DatabaseEntry.EMAIL, email);
            contentValues.put(DatabaseEntry.CONFIRMED_PASSWORD, password);
            db.insert(DatabaseEntry.TABLE_NAME, null, contentValues);
            return true;
        } else
            return false;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(String.format(Locale.US,"DROP TABLE IF EXISTS %s", DatabaseEntry.TABLE_NAME));
        onCreate(db);
    }
}
