package edu.fsu.cs.cen4020.loginuserinterface;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

public class Activity_Login extends AppCompatActivity {

    RelativeLayout relLay1, relLay2;
    TextView titleView;
    Button loginBtn, signUpBtn;
    EditText username, password;
    SQLiteOpenHelper openHelper;
    SQLiteDatabase db;
    Cursor cursor;


    Handler handler = new Handler();
    Runnable runnable = new Runnable() {
        @Override
        public void run() {
            relLay1.setVisibility(View.VISIBLE);
            relLay2.setVisibility(View.VISIBLE);
            titleView.setVisibility(View.VISIBLE);


        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity__login);

        openHelper = new DatabaseHelper(this);
        db = openHelper.getReadableDatabase();

        relLay1 = findViewById(R.id.rel_layout1);
        relLay2 = findViewById(R.id.rel_layout2);
        titleView = findViewById(R.id.textView_title);
        loginBtn = findViewById(R.id.button_login);
        signUpBtn = findViewById(R.id.button_signUp);
        username = findViewById(R.id.editText_username);
        password = findViewById(R.id.editText_password);

        loginBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                onLoginClicked(v);
                String usernameStr = username.getText().toString();
                String passwordStr = password.getText().toString();
                cursor = db.rawQuery("SELECT * FROM " + DatabaseHelper.DatabaseEntry.TABLE_NAME + " WHERE "
                        + DatabaseHelper.DatabaseEntry.USERNAME
                        + "=? AND "
                        + DatabaseHelper.DatabaseEntry.PASSWORD
                        + "=?", new String [] {usernameStr, passwordStr});

                if (cursor != null) {
                    if (cursor.getCount() > 0) {
                        cursor.moveToNext();
                        Toast.makeText(getApplicationContext(), "Login Successful!", Toast.LENGTH_LONG).show();
                    }
                    else {
                        Toast.makeText(getApplicationContext(), "Username or Password incorrect. Try again!", Toast.LENGTH_LONG).show();
                    }
                }
                }
        });

        signUpBtn.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                //onSignUpClicked(v);
            }
        });


        handler.postDelayed(runnable, 2000);

    }

    boolean isEmpty(EditText text) {
        CharSequence str = text.getText().toString();
        return TextUtils.isEmpty(str);
    }

//    boolean checkEmployeeID() {
//
//        String employeeId = editEmployeeID.toString();
//        boolean exists = false;
//
//        ContentValues values = getContentValues();
//        if (isExistingEmployee(employeeId)) {
//            // Update employee
//            String selectionClause = MyEmployeeProvider.EmployeeContract._ID + " = ?";
//            String[] selectionArgs = new String[] { employeeId };
//            getActivity().getApplicationContext().getContentResolver().update(
//                    MyEmployeeProvider.CONTENT_URI,
//                    values,
//                    selectionClause,
//                    selectionArgs
//            );
//            editEmployeeID.setError("Employee ID already exists");
//            exists = true;
//
//        }
//        else {
//            // Insert new employee
//            return exists;
//
//        }
//        return exists;
//
//    }

//    boolean isExistingEmployee(String employeeId) {
//        boolean exists;
//
//        String selectionClause = MyEmployeeProvider.EmployeeContract._ID + " = ?";
//        String[] selectionArgs = new String[] { employeeId };
//        Cursor cursor = getActivity().getApplicationContext().getContentResolver().query(
//                MyEmployeeProvider.CONTENT_URI, null, selectionClause, selectionArgs, null
//        );
//        assert cursor != null;
//        exists = cursor.getCount() != 0;
//        cursor.close();
//
//        return exists;
//    }

//    /**
//     * Constructs a ContentValues object representation of the form fields' values
//     */
//    private ContentValues getContentValues() {
//        ContentValues values = new ContentValues();
//        values.put(MyEmployeeProvider.EmployeeContract._ID, editEmployeeID.getText().toString());
//        values.put(MyEmployeeProvider.EmployeeContract.NAME, editName.getText().toString());
//        values.put(MyEmployeeProvider.EmployeeContract.GENDER, radioButtons.toString());
//        values.put(MyEmployeeProvider.EmployeeContract.EMAIL_ADDRESS, editEmail.getText().toString());
//        values.put(MyEmployeeProvider.EmployeeContract.ACCESS_CODE,
//                Integer.parseInt(editAccessCode.getText().toString()));
//        values.put(MyEmployeeProvider.EmployeeContract.DEPARTMENT, departments.getSelectedItemPosition());
//        return values;
//    }


//    private void onSignUpClicked(View w){
//        Intent myIntent = new Intent(w.getContext(), signUpActivity.class);
//        Bundle bundle = new Bundle();
//
//
//        bundle.putString("USERNAME", username.getText().toString());
//
//        myIntent.putExtras(bundle);
//        startActivityForResult(myIntent, 0);
//    }

    private void onLoginClicked(View w)
    {
         //if username already registered, then loginBtn
        if (isEmpty(username)) {

            username.setError("Enter your username");
        }
        else
            username.setError(null);


        if (isEmpty(password)) {

            password.setError("Enter your password");
        }
        else
            password.setError(null);

//        // else, loginBtn failed -> must register first
//        username.setError("Unable to locate username in database.  Please register.");
//        password.setError("Incorrect password");

    }
}
