package edu.fsu.cs.cen4020.loginuserinterface;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;
import android.util.Log;

import java.util.Locale;

import static android.content.ContentValues.TAG;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "showMe.db";
    public static final int DATABASE_VERSION = 1;
    SQLiteDatabase db;


    public class DatabaseEntry implements BaseColumns {
        public static final String TABLE_NAME = "signUp";

        public static final String _ID = "_id";
        public static final String USERNAME = "email";
        public static final String NAME = "name";
        public static final String GENDER = "gender";
        public static final String PASSWORD = "password";

    }
    public static final String SQL_CREATE_TRANSACTION_TABLE =
            String.format(Locale.US, "CREATE TABLE %s (" // TransactionEntry.TABLE
                            + " %s INTEGER PRIMARY KEY AUTOINCREMENT, " // COLUMN_ID
                            + " %s TEXT NOT NULL," // COLUMN_EMAILL
                            + " %s TEXT NOT NULL," // COLUMN_NAME
                            + " %s TEXT NOT NULL," // COLUMN_GENDER
                            + " %s INTEGER);", //COLUMN_ACCESSCODE
                    DatabaseEntry.TABLE_NAME, DatabaseEntry._ID, DatabaseEntry.USERNAME,
                    DatabaseEntry.NAME, DatabaseEntry.GENDER, DatabaseEntry.PASSWORD);

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.i(TAG, "Creating: " + SQL_CREATE_TRANSACTION_TABLE);
        db.execSQL(SQL_CREATE_TRANSACTION_TABLE);

    }
//
//    public void insertCreate(Context context) {
//        db = this.getWritableDatabase();
//        ContentValues values = new ContentValues();
//        values.put(DatabaseEntry.USERNAME, context.);
//    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(String.format(Locale.US,
                "DROP TABLE IF EXISTS %s", DatabaseEntry.TABLE_NAME));
        onCreate(db);
    }
}
